# Estado de reconstrucción de presentaciones

Fecha: 2026-10-30.

- **Clase 1: reconstruida y verificada.** `01_introduccion.typ`, `01_introduccion.pdf` y `01_introduccion_handout.pdf` contienen 30 diapositivas de exposición y 5 de respaldo. Los dos PDFs tienen 35 páginas en 16:9. Se revisaron visualmente páginas de conceptos, cálculos y solución.
- **Clases 2–13: borradores anteriores.** Sus archivos aún no cumplen el nuevo criterio de profundidad.
- `prototipo_wald.*` valida el estilo y una demostración de la clase 3; no reemplaza esa clase.
- `MATRIZ_FUENTES.md` registra fuentes y riesgos. El ZIP `presentaciones_typst.zip` anterior es una instantánea previa a esta reconstrucción; para la clase 1 usar `clase1_reconstruida.zip`.

La clase 1 distingue el ejemplo binario de pérdidas del SSCH tabular. Los números SSCH se reprodujeron desde `lab00_ssch.py` (SHA-256 `ce0d025cdc8e35d506bb465e6e40b20448db67b7744c61d21aef11864e37ba66`). El valor óptimo calculado por iteración y evaluación directa coincide hasta aproximadamente 1e-11. Son cálculos del simulador, sin interpretación clínica.
